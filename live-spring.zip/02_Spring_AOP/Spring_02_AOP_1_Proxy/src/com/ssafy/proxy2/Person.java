package com.ssafy.proxy2;

public interface Person {
	public abstract void coding();
}