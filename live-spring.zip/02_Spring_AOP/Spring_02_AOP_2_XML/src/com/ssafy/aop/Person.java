package com.ssafy.aop;

public interface Person {
	public abstract int coding() throws OuchException;
}