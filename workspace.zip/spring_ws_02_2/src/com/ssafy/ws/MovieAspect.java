package com.ssafy.ws;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
@Aspect
public class MovieAspect {
	@Pointcut("execution(* com.ssafy.ws.*.doSomething())")
    public void mypt() {}

    public void before() {
        System.out.println("영화관을 갑니다.");
    }
    public void afterReturn() {
        System.out.println("영화가 끝나고 나옵니다.");
    }
    
    public void afterThrow() {
        System.out.println("전화를 받습니다.");
    }

    public void after() {
        System.out.println("집에 갑니다..");
    }
}
