package com.ssafy.ws;

public class CallException extends Exception{
	private static final long serialVersionUID = 1L;

	public void handleException() {
		System.out.println("전화를 받습니다.");
	}
}
