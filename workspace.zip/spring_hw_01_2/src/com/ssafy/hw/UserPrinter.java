package com.ssafy.hw;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class UserPrinter {

	@Autowired
	User user;

	// Spring에서 주입받은 User 정보 출력하기
	public void printUserRank() {
		System.out.println("I'm " + user.getRank() + "user.");
	}

}
