package com.ssafy.hw;

public interface User {
	String getRank();
}
