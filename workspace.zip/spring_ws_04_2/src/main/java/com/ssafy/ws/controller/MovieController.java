package com.ssafy.ws.controller;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.ws.model.dto.Movie;
import com.ssafy.ws.model.dto.User;

// 이 클래스가 컨트롤러 임을 어노테이션으로 설정, 컴포넌트 스캔을 통해 빈으로 등록
@Controller
public class MovieController {
	List<Movie> movies = new ArrayList<>();
	{
		movies.add(new Movie(1, "베놈 2: 렛 데어 비 카니지", "앤디 서키스", "액션", 97));
		movies.add(new Movie(2, "기생충", "봉준호", "드라마", 131));
		movies.add(new Movie(3, "해리포터와 마법사의 돌", "크리스 콜럼버스", "판타지", 152));
	}

	/**
	 * '/' 또는 '/index' 요청이 get 방식으로 들어왔을 때 index로 연결한다.
	 * 
	 * @return
	 */
	@GetMapping({ "/", "/index" })
	public String showIndex() {
		return "index";
	}

	@PostMapping("/login")
	public String login(HttpSession session, @RequestParam("id") String id, @RequestParam("password") String password) {
//		HttpSession session = request.getSession();
		// UserService라는것을 만들어서 호출 한다.
		if (id.equals("ssafy") && password.equals("1234")) {
			// 로그인 성공!
			session.setAttribute("id", id);
//			return "index"; //포워딩
			return "redirect:/";
		}
		// 아니라면 다시 로그인페이지로 ㄱㄱ
		return "redirect:/login";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
//		session.removeAttribute("id"); 
		session.invalidate();
		
		return "redirect:/index";
	}
 
	/**
	 * <pre>
	 * /login 요청이 post 방식으로 왔을 때 login 처리한다.
	 * </pre>
	 * 
	 * 사용자의 요청에서 계정 정보를 추출해 로그인 처리한다. 일단 사용자 id가 ssafy, 비밀번호가 1234면 로그인에 성공으로 간주한다.
	 * 로그인 성공 시 session에 정보를 담고 redirect로 index로 이동한다. 그렇지 않을 경우는 로그인 실패 메시지를 model에
	 * 담고 forward로 index로 이동한다.
	 * 
	 * @param user    전달된 파라미터는 ModelAttribute를 통해서 객체로 받을 수 있다.
	 * @param session 사용자 정보를 세션에 저장하기 위해 사용한다.
	 * @param model   Request scope에 정보를 저장하기 위해서 사용된다.
	 * @return
	 */

	/**
	 * <pre>
	 * /logout을 get 방식으로 요청했을 때 session을 만료 시키고 로그아웃 처리한다.
	 * </pre>
	 * 
	 * 다음 경로는 redirect 형태로 /index로 이동한다.
	 * 
	 * @param session
	 * @return
	 */

	/**
	 * <pre>
	 * /list를 get 방식으로 요청할 때 도서 정보를 보여준다.
	 * </pre>
	 * 
	 * 아직 MVC의 model 영역을 완성하지 않았기 때문에 여러 개의 Movie을 직접 생성해서 List 형태로 전달한다. 정보를 Model
	 * 객체에 저장 후 forward로 list를 호출한다.
	 * 
	 * @return
	 */
	@GetMapping("/list")
	public String showList(Model model) {
		model.addAttribute("movies", movies);
		return "list";
	}

	/**
	 * '/regist' 요청이 get 방식으로 들어왔을 때 regist로 연결한다.
	 * 
	 * @return
	 */
	@GetMapping("/regist")
	public String showRegistForm() {
		return "regist";
	}

	/**
	 * '/regist' 요청이 post 방식으로 들어왔을 때 전달된 Movie 객체를 regist_result로 연결한다.
	 * 
	 * @param movie
	 * @return
	 */
	 @PostMapping("/regist")
	 public String doRegist(Movie movie, Model model) {
	 	// 전달할 객체
	 	model.addAttribute("movie" , movie);
	 	movies.add(movie);
	 	
	 	return "regist_result";
	 }
}
