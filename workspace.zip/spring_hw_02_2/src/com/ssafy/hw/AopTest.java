package com.ssafy.hw;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.ssafy.hw.User;

public class AopTest {

	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("applicationContext.xml");

		User g = context.getBean("generalUser", User.class);
		User adm = context.getBean("adminUser", User.class);
		
		System.out.println("******1.GeneralUser");
		try {
			g.useApp();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("******2.AdminUSer");
		try {
			adm.useApp();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
	}

}
