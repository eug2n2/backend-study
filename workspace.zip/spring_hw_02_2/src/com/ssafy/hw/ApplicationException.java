package com.ssafy.hw;

public class ApplicationException extends Exception {
	private static final long serialVersionUID = 1L;

	public void handleException() {
		System.out.println("문제가 생겨서 종료합니다. ");
	}
}
