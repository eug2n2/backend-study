package com.ssafy.hw;

public interface User {
	void useApp() throws ApplicationException;
}
