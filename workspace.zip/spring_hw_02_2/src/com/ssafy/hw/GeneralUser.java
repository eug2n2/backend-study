package com.ssafy.hw;

import java.util.Random;

import org.springframework.stereotype.Component;
@Component
public class GeneralUser implements User{
	
	public void useApp() throws ApplicationException {
		System.out.println("애플리케이션을 사용합니다.");
		if(new Random().nextBoolean())
			throw new ApplicationException();
	}

}
