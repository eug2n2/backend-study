package com.ssafy.ws;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component(value ="audience")
public class Audience {
	private Movie movie;
	@Autowired
	public void setComputer(@Qualifier("actionMovie")  Movie movie) {
		this.movie = movie;
	}
	public void watch() {
		System.out.println("^_^ " + movie.getInfo());
	}
}
