package com.ssafy.ws;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MovieTest {
    public static void main(String[] args) {
        // Spring IoC 컨테이너 생성
        ApplicationContext context = new GenericXmlApplicationContext("applicationContext.xml");

        // Audience 빈 가져오기
        Audience audience = context.getBean(Audience.class);

        // 영화 관람
        audience.watch();
    }
}
