package com.ssafy.ws;

public interface Movie {
	String getInfo();
}
