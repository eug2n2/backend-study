package com.ssafy.ws;

import org.springframework.stereotype.Component;

@Component()
public class Comic implements Movie{
	    public String getInfo() {
	        return "코믹 영화를 관람합니다.";
	    }
}