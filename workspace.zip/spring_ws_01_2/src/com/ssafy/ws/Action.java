package com.ssafy.ws;

import org.springframework.stereotype.Component;

@Component("actionMovie")
public class Action implements Movie{
	    public String getInfo() {
	        return "액션영화를 관람합니다.";
	    }
}
